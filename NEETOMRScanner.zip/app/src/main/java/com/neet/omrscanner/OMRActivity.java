package com.neet.omrscanner;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.neet.omrscanner.adapters.QuestionAdapter;
import com.neet.omrscanner.models.Question;
import java.io.Serializable;
import java.util.List;

public class OMRActivity extends AppCompatActivity {
    private CountDownTimer cdt;
    private List<Question> questions;
    private long startMs;

    @SuppressWarnings("unchecked")
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_omr);
        questions = (List<Question>) getIntent().getSerializableExtra("questions");
        int mins  = getIntent().getIntExtra("timer_min", 0);
        TextView tvTimer = findViewById(R.id.tvTimer);
        RecyclerView rv  = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(new QuestionAdapter(this, questions));
        startMs = System.currentTimeMillis();
        if (mins > 0) {
            tvTimer.setVisibility(View.VISIBLE);
            cdt = new CountDownTimer(mins * 60_000L, 1000) {
                public void onTick(long left) {
                    long m = left/60000, sec = (left%60000)/1000;
                    tvTimer.setText(String.format("Time: %02d:%02d", m, sec));
                    if (left < 60000) tvTimer.setTextColor(0xFFFF5252);
                }
                public void onFinish() { tvTimer.setText("Time: 00:00"); submit(); }
            }.start();
        } else tvTimer.setVisibility(View.GONE);
        ((Button)findViewById(R.id.btnSubmit)).setOnClickListener(v -> confirmSubmit());
    }

    private void confirmSubmit() {
        new AlertDialog.Builder(this).setTitle("Submit Test")
            .setMessage("Submit now?")
            .setPositiveButton("Submit", (d,w) -> submit())
            .setNegativeButton("Cancel", null).show();
    }

    private void submit() {
        if (cdt != null) cdt.cancel();
        long taken = (System.currentTimeMillis() - startMs) / 1000;
        Intent i = new Intent(this, ResultActivity.class);
        i.putExtra("questions", (Serializable) questions);
        i.putExtra("time_taken", taken);
        startActivity(i); finish();
    }

    @Override public void onBackPressed() { confirmSubmit(); }
    @Override protected void onDestroy() { super.onDestroy(); if (cdt != null) cdt.cancel(); }
}
