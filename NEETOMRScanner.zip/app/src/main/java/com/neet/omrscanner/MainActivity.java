package com.neet.omrscanner;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        ((Button)findViewById(R.id.btnNewTest)).setOnClickListener(v ->
            startActivity(new Intent(this, ScanActivity.class)));
        ((Button)findViewById(R.id.btnHistory)).setOnClickListener(v ->
            startActivity(new Intent(this, HistoryActivity.class)));
    }
}
