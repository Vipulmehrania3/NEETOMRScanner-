package com.neet.omrscanner.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.neet.omrscanner.models.TestResult;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB  = "neet_omr.db";
    private static final String TBL = "results";

    public DatabaseHelper(Context ctx) { super(ctx, DB, null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TBL +
            "(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, total INTEGER," +
            " correct INTEGER, wrong INTEGER, unattempted INTEGER," +
            " score INTEGER, accuracy REAL, time INTEGER)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int o, int n) {
        db.execSQL("DROP TABLE IF EXISTS " + TBL); onCreate(db);
    }

    public void insert(TestResult r) {
        ContentValues v = new ContentValues();
        v.put("date", r.getDate()); v.put("total", r.getTotalQuestions());
        v.put("correct", r.getCorrect()); v.put("wrong", r.getWrong());
        v.put("unattempted", r.getUnattempted()); v.put("score", r.getScore());
        v.put("accuracy", r.getAccuracy()); v.put("time", r.getTimeTaken());
        getWritableDatabase().insert(TBL, null, v);
    }

    public List<TestResult> getAll() {
        List<TestResult> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery("SELECT * FROM " + TBL + " ORDER BY id DESC", null);
        while (c.moveToNext()) {
            TestResult r = new TestResult();
            r.setId(c.getLong(0)); r.setDate(c.getString(1));
            r.setTotalQuestions(c.getInt(2)); r.setCorrect(c.getInt(3));
            r.setWrong(c.getInt(4)); r.setUnattempted(c.getInt(5));
            r.setScore(c.getInt(6)); r.setAccuracy(c.getFloat(7));
            r.setTimeTaken(c.getLong(8));
            list.add(r);
        }
        c.close(); return list;
    }

    public void clearAll() { getWritableDatabase().delete(TBL, null, null); }
}
