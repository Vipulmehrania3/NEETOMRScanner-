package com.neet.omrscanner;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.neet.omrscanner.models.Question;
import com.neet.omrscanner.utils.AnswerKeyParser;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;

public class ScanActivity extends AppCompatActivity {

    private ImageView ivPreview;
    private ProgressBar pb;
    private TextView tvStatus;
    private LinearLayout layTimer;
    private EditText etTimer;
    private Button btnStart, btnUpload;
    private List<Question> detected;

    private final ActivityResultLauncher<Intent> picker =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r -> {
            if (r.getResultCode() == RESULT_OK && r.getData() != null)
                processImage(r.getData().getData());
        });

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_scan);
        ivPreview = findViewById(R.id.ivPreview);
        pb        = findViewById(R.id.progressBar);
        tvStatus  = findViewById(R.id.tvStatus);
        layTimer  = findViewById(R.id.layoutTimer);
        etTimer   = findViewById(R.id.etTimer);
        btnStart  = findViewById(R.id.btnStart);
        btnUpload = findViewById(R.id.btnUpload);
        btnUpload.setOnClickListener(v -> checkPerm());
        btnStart.setOnClickListener(v -> startTest());
    }

    private void checkPerm() {
        String perm = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            ? Manifest.permission.READ_MEDIA_IMAGES
            : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{perm}, 1);
        else openPicker();
    }

    private void openPicker() {
        picker.launch(new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI));
    }

    private void processImage(Uri uri) {
        try {
            Bitmap bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            ivPreview.setImageBitmap(bmp);
            ivPreview.setVisibility(View.VISIBLE);
            pb.setVisibility(View.VISIBLE);
            tvStatus.setText("Scanning answer key...");
            tvStatus.setVisibility(View.VISIBLE);
            btnStart.setVisibility(View.GONE);
            layTimer.setVisibility(View.GONE);
            AnswerKeyParser.parseFromBitmap(bmp, new AnswerKeyParser.ParseCallback() {
                public void onSuccess(List<Question> qs) {
                    runOnUiThread(() -> {
                        detected = qs;
                        pb.setVisibility(View.GONE);
                        tvStatus.setText("Detected " + qs.size() + " questions. Set timer and start!");
                        layTimer.setVisibility(View.VISIBLE);
                        btnStart.setVisibility(View.VISIBLE);
                    });
                }
                public void onFailure(String err) {
                    runOnUiThread(() -> {
                        pb.setVisibility(View.GONE);
                        tvStatus.setText("Error: " + err);
                    });
                }
            });
        } catch (IOException e) {
            Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
        }
    }

    private void startTest() {
        if (detected == null || detected.isEmpty()) {
            Toast.makeText(this, "No questions detected", Toast.LENGTH_SHORT).show();
            return;
        }
        int mins = 0;
        String t = etTimer.getText().toString().trim();
        if (!t.isEmpty()) {
            try { mins = Integer.parseInt(t); }
            catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid timer value", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        Intent i = new Intent(this, OMRActivity.class);
        i.putExtra("questions", (Serializable) detected);
        i.putExtra("timer_min", mins);
        startActivity(i);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (req == 1 && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED)
            openPicker();
        else
            Toast.makeText(this, "Permission required to pick image", Toast.LENGTH_SHORT).show();
    }
}
