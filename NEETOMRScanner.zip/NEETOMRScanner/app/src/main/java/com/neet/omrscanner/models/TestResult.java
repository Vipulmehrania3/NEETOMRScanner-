package com.neet.omrscanner.models;

public class TestResult {
    private long id;
    private String date;
    private int totalQuestions, correct, wrong, unattempted, score;
    private float accuracy;
    private long timeTaken;

    public long   getId()                  { return id; }
    public void   setId(long v)            { id = v; }
    public String getDate()                { return date; }
    public void   setDate(String v)        { date = v; }
    public int    getTotalQuestions()      { return totalQuestions; }
    public void   setTotalQuestions(int v) { totalQuestions = v; }
    public int    getCorrect()             { return correct; }
    public void   setCorrect(int v)        { correct = v; }
    public int    getWrong()               { return wrong; }
    public void   setWrong(int v)          { wrong = v; }
    public int    getUnattempted()         { return unattempted; }
    public void   setUnattempted(int v)    { unattempted = v; }
    public int    getScore()               { return score; }
    public void   setScore(int v)          { score = v; }
    public float  getAccuracy()            { return accuracy; }
    public void   setAccuracy(float v)     { accuracy = v; }
    public long   getTimeTaken()           { return timeTaken; }
    public void   setTimeTaken(long v)     { timeTaken = v; }
}
