package com.neet.omrscanner.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import com.neet.omrscanner.R;
import com.neet.omrscanner.models.Question;
import java.util.List;

public class QuestionAdapter extends RecyclerView.Adapter<QuestionAdapter.VH> {

    private final List<Question> qs;
    private final Context ctx;
    private boolean resultMode = false;

    public QuestionAdapter(Context ctx, List<Question> qs) {
        this.ctx = ctx;
        this.qs  = qs;
    }

    public void setResultMode(boolean b) { resultMode = b; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int t) {
        return new VH(LayoutInflater.from(ctx).inflate(R.layout.item_question, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Question q = qs.get(pos);
        h.qNum.setText("Q" + q.getQuestionNumber());

        TextView[] b = {h.b1, h.b2, h.b3, h.b4};
        for (TextView bv : b) {
            bv.setBackgroundResource(R.drawable.bubble_default);
            bv.setTextColor(ctx.getResources().getColor(R.color.bubble_text, null));
        }

        if (resultMode) {
            b[q.getCorrectAnswer() - 1].setBackgroundResource(R.drawable.bubble_correct);
            b[q.getCorrectAnswer() - 1].setTextColor(0xFFFFFFFF);
            if (q.isWrong()) {
                b[q.getUserAnswer() - 1].setBackgroundResource(R.drawable.bubble_wrong);
                b[q.getUserAnswer() - 1].setTextColor(0xFFFFFFFF);
            }
        } else {
            if (q.getUserAnswer() != 0) {
                b[q.getUserAnswer() - 1].setBackgroundResource(R.drawable.bubble_selected);
                b[q.getUserAnswer() - 1].setTextColor(0xFFFFFFFF);
            }
            for (int i = 0; i < 4; i++) {
                final int ans = i + 1;
                b[i].setOnClickListener(v -> {
                    v.startAnimation(AnimationUtils.loadAnimation(ctx, R.anim.bubble_tap));
                    q.setUserAnswer(ans);
                    notifyItemChanged(h.getAdapterPosition());
                });
            }
        }
    }

    @Override public int getItemCount() { return qs.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView qNum, b1, b2, b3, b4;
        VH(@NonNull View v) {
            super(v);
            qNum = v.findViewById(R.id.tvQNum);
            b1   = v.findViewById(R.id.bubble1);
            b2   = v.findViewById(R.id.bubble2);
            b3   = v.findViewById(R.id.bubble3);
            b4   = v.findViewById(R.id.bubble4);
        }
    }
}
