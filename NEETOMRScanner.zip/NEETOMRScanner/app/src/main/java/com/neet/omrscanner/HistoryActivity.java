package com.neet.omrscanner;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.neet.omrscanner.adapters.HistoryAdapter;
import com.neet.omrscanner.models.TestResult;
import com.neet.omrscanner.utils.DatabaseHelper;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private RecyclerView rv;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_history);
        db      = new DatabaseHelper(this);
        rv      = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        ((Button) findViewById(R.id.btnClear)).setOnClickListener(v ->
            new AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Delete all test results?")
                .setPositiveButton("Delete", (d, w) -> { db.clearAll(); load(); })
                .setNegativeButton("Cancel", null)
                .show());
        load();
    }

    private void load() {
        List<TestResult> list = db.getAll();
        if (list.isEmpty()) {
            rv.setVisibility(View.GONE);
            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            rv.setVisibility(View.VISIBLE);
            tvEmpty.setVisibility(View.GONE);
            rv.setLayoutManager(new LinearLayoutManager(this));
            rv.setAdapter(new HistoryAdapter(this, list));
        }
    }
}
